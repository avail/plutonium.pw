(function() {
    var consoleShown = false;

    var history = {
        index: 0,
        list: [],
        push: function(value) {
            var pos = this.list.indexOf(value);
            if (pos !== -1) {
                this.list.splice(pos, 1);
            }

            this.list.push(value);
        },
        next: function() {
            if (this.index < 0) this.index = 0;
            if (this.index > 0) --this.index;
            if (this.index < this.list.length) return this.list[this.index];
            return '';
        },
        back: function() {
            if (this.list.length <= 0) return '';
            if (this.index >= this.list.length) this.index = this.list.length - 1;
            if (this.index < this.list.length - 1) ++this.index;
            if (this.index < this.list.length) return this.list[this.index];
            return '';
        },
        reset: function() {
            this.index = this.list.length;
        },
    };

    function frameLoop() {
        if (consoleShown) {
            $('#console input').focus();
        }

        window.requestAnimationFrame(frameLoop);
    }

    function showConsole() {
        window.postMessage('lockInput');

        $('#console').show();
        $('#console').animate(
            {
                top: '5px',
            },
            200,
        );

        consoleShown = true;
        history.reset();
    }

    function hideConsole() {
        consoleShown = false;
        history.reset();

        $('#console').animate(
            {
                top: '-40px',
            },
            200,
            function() {
                $('#console input').val('');
                $('#console').hide();
            },
        );

        window.postMessage('unlockInput');
    }

    function submitInput() {
        history.push($('#console input').val());
        window.postMessage('execute', function() {}, $('#console input').val());
        window.postMessage('closeConsole');
        hideConsole();
    }

    window.onMessage('toggleConsole', function(active) {
        if (active) showConsole();
        else hideConsole();
    });

    $(window).on('load', function() {
        frameLoop();

        $('#console input').on('keyup', function(e) {
            if (e.keyCode == 13) {
                submitInput();
            } else if (e.keyCode == 38) {
                // Up
                $('#console input').val(history.next());
                return false;
            } else if (e.keyCode == 40) {
                // Down
                $('#console input').val(history.back());
                return false;
            }
        });
    });
})();
