$(document).ready(function () {
  window.fadeView("init", 0);
});
