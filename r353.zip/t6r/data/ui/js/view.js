(function() {
    'use strict';
    window.loadView = function(view, callback) {
        $('#view').load('views/' + view + '.html', undefined, callback);
    };

    window.fadeView = (view, outTime = 300, inTime = 300) => {
        var container = $('#view');
        container.fadeTo(outTime, 0, () => {
            window.loadView(view, () => {
                container.fadeTo(inTime, 1);
            });
        });
    };
})();
