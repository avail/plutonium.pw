if (window.innerWidth == 800 && window.innerHeight == 600) {
    $('li#search').css('width', '75.7%');
    $('a#connect_btn').css('width', '100%');
    $('a#copy_ip').css('width', '100%');
    $('a#copy_ip').css('margin-top', '5px');
}
if (window.innerWidth == 1024 && window.innerHeight == 600) {
    $('li#search').css('width', '81%');
    $('a#connect_btn').css('width', '100%');
    $('a#copy_ip').css('width', '100%');
    $('a#copy_ip').css('margin-top', '5px');
}

if (window.innerWidth == 1024 && window.innerHeight == 768) {
    $('li#search').css('width', '81%');
    $('a#connect_btn').css('width', '100%');
    $('a#copy_ip').css('width', '100%');
    $('a#copy_ip').css('margin-top', '5px');
}
if (window.innerWidth == 1152 && window.innerHeight == 864) {
    $('li#search').css('width', '83.1%');
    $('a#connect_btn').css('width', '100%');
    $('a#copy_ip').css('width', '100%');
    $('img#map_preview').css('display', 'none');
    $('a#copy_ip').css('margin-top', '5px');
    $('div#servername').css('font-size', '27px');
}

if (window.innerWidth == 1280 && window.innerHeight == 720) {
    $('ul.menu_horizontal_info_button').css('display', 'none');
    $('li#search').css('width', '84.9%');
    $('a#connect_btn').css('width', '100%');
    $('a#copy_ip').css('width', '100%');
    $('a#copy_ip').css('margin-top', '5px');
    $('div#servername').css('font-size', '27px');
    $('h5#map_name').css('font-size', '26px');
    $('h5#map_name').css('margin-bottom', '0px');
    $('p#cplayers').css('margin-top', '0px');
    $('p#cplayers').css('margin-bottom', '0px');
    $('p#gametype').css('margin-bottom', '0px');

} 
if (window.innerWidth == 1280 && window.innerHeight == 768) {
    $('ul.menu_horizontal_info_button').css('display', 'none');
    $('li#search').css('width', '84.9%');
    $('a#connect_btn').css('width', '100%');
    $('a#copy_ip').css('width', '100%');
    $('a#copy_ip').css('margin-top', '5px');
    $('div#servername').css('font-size', '27px');
    $('h5#map_name').css('font-size', '26px');
    $('h5#map_name').css('margin-bottom', '0px');
    $('p#cplayers').css('margin-top', '0px');
    $('p#cplayers').css('margin-bottom', '0px');
    $('p#gametype').css('margin-bottom', '0px');
} 

if (window.innerWidth == 1280 && window.innerHeight == 800) {
    $('ul.menu_horizontal_info_button').css('display', 'none');
    $('li#search').css('width', '84.9%');
    $('a#connect_btn').css('width', '100%');
    $('a#copy_ip').css('width', '100%');
    $('a#copy_ip').css('margin-top', '5px');
    $('div#servername').css('font-size', '27px');
    $('h5#map_name').css('font-size', '26px');
    $('h5#map_name').css('margin-bottom', '0px');
    $('p#cplayers').css('margin-top', '0px');
    $('p#cplayers').css('margin-bottom', '0px');
    $('p#gametype').css('margin-bottom', '0px');
} 

if (window.innerWidth == 1280 && window.innerHeight == 1024) {
    $('ul.menu_horizontal_info_button').css('display', 'none');
    $('li#search').css('width', '84.9%');
    $('a#connect_btn').css('width', '100%');
    $('a#copy_ip').css('width', '100%');
    $('a#copy_ip').css('margin-top', '5px');
    $('div#servername').css('font-size', '27px');
    $('h5#map_name').css('font-size', '26px');
    $('h5#map_name').css('margin-bottom', '0px');
    $('p#cplayers').css('margin-top', '0px');
    $('p#cplayers').css('margin-bottom', '0px');
    $('p#gametype').css('margin-bottom', '0px');
}

if (window.innerWidth == 1400 && window.innerHeight == 1050) {
    $('ul.menu_horizontal_info_button').css('display', 'none');
    $('li#search').css('width', '86.3%');
    $('a#connect_btn').css('width', '100%');
    $('a#copy_ip').css('width', '100%');
    $('a#copy_ip').css('margin-top', '5px');
    $('div#servername').css('font-size', '27px');
    $('h5#map_name').css('font-size', '26px');
    $('h5#map_name').css('margin-bottom', '0px');
    $('p#cplayers').css('margin-top', '0px');
    $('p#cplayers').css('margin-bottom', '0px');
    $('p#gametype').css('margin-bottom', '0px');
}
if (window.innerWidth == 1440 && window.innerHeight == 900) {
    $('ul.menu_horizontal_info_button').css('display', 'none');
    $('li#search').css('width', '86.6%');
    $('a#connect_btn').css('width', '100%');
    $('a#copy_ip').css('width', '100%');
    $('a#copy_ip').css('margin-top', '5px');
    $('div#servername').css('font-size', '27px');
    $('h5#map_name').css('font-size', '26px');
    $('h5#map_name').css('margin-bottom', '0px');
    $('p#cplayers').css('margin-top', '0px');
    $('p#cplayers').css('margin-bottom', '0px');
    $('p#gametype').css('margin-bottom', '0px');
}
if (window.innerWidth == 1600 && window.innerHeight == 900) {
    $('ul.menu_horizontal_info_button').css('display', 'none');
    $('li#search').css('width', '88%');
    $('a#connect_btn').css('width', '100%');
    $('a#copy_ip').css('width', '100%');
    $('a#copy_ip').css('margin-top', '5px');
    $('div#servername').css('font-size', '27px');
    $('h5#map_name').css('font-size', '26px');
    $('h5#map_name').css('margin-bottom', '0px');
    $('p#cplayers').css('margin-top', '0px');
    $('p#cplayers').css('margin-bottom', '0px');
    $('p#gametype').css('margin-bottom', '0px');
}
if (window.innerWidth == 1600 && window.innerHeight == 1200) {
    $('ul.menu_horizontal_info_button').css('display', 'none');
    $('li#search').css('width', '88%');
    $('a#connect_btn').css('width', '100%');
    $('a#copy_ip').css('width', '100%');
    $('a#copy_ip').css('margin-top', '5px');
    $('div#servername').css('font-size', '27px');
    $('h5#map_name').css('font-size', '26px');
    $('h5#map_name').css('margin-bottom', '0px');
    $('p#cplayers').css('margin-top', '0px');
    $('p#cplayers').css('margin-bottom', '0px');
    $('p#gametype').css('margin-bottom', '0px');
}
if (window.innerWidth == 1680 && window.innerHeight == 1050) {
    $('ul.menu_horizontal_info_button').css('display', 'none');
    $('li#search').css('width', '88.5%');
    $('a#connect_btn').css('width', '100%');
    $('a#copy_ip').css('width', '100%');
    $('a#copy_ip').css('margin-top', '5px');
    $('div#servername').css('font-size', '27px');
    $('h5#map_name').css('font-size', '26px');
    $('h5#map_name').css('margin-bottom', '0px');
    $('p#cplayers').css('margin-top', '0px');
    $('p#cplayers').css('margin-bottom', '0px');
    $('p#gametype').css('margin-bottom', '0px');
}

else if (window.innerWidth == 1920) {
    $('li#search').css('width', '90%');
   $('a#connect_btn').css('width', '100%');
    $('a#copy_ip').css('width', '100%');
    $('a#copy_ip').css('margin-top', '5px');
} else if (window.innerWidth == 2048) {
    $('li#search').css('width', '90.7%');
   $('a#connect_btn').css('width', '100%');
    $('a#copy_ip').css('width', '100%');
    $('a#copy_ip').css('margin-top', '5px');
} else if (window.innerWidth == 2560) {
    $('li#search').css('width', '92.5%');
 $('a#connect_btn').css('width', '100%');
    $('a#copy_ip').css('width', '100%');
    $('a#copy_ip').css('margin-top', '5px');
} else if (window.innerWidth == 3200) {
    $('li#search').css('width', '93%');
    $('li#refreshServers').css('width', '5.7%');
    $('a#bt_refresh').css('width', '100%');
 $('a#connect_btn').css('width', '100%');
    $('a#copy_ip').css('width', '100%');
    $('a#copy_ip').css('margin-top', '5px');
} else if (window.innerWidth == 3840) {
    $('li#search').css('width', '93%');
    $('a#bt_refresh').css('width', '100%');
    $('li#refreshServers').css('width', '5.9%');
 $('a#connect_btn').css('width', '100%');
    $('a#copy_ip').css('width', '100%');
    $('a#copy_ip').css('margin-top', '5px');
} else if (window.innerWidth == 5120) {
    $('li#search').css('width', '93%');
    $('a#bt_refresh').css('width', '100%');
    $('li#refreshServers').css('width', '6.2%');
$('a#connect_btn').css('width', '100%');
    $('a#copy_ip').css('width', '100%');
    $('a#copy_ip').css('margin-top', '5px');
}