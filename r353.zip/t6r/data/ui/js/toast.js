(function() {
    'use strict';
    window.toast = window.toast || {};

    var icons = [];
    icons['notify-success'] = 'fa-check';
    icons['notify-info'] = 'fa-info';
    icons['notify-warn'] = 'fa-exclamation';
    icons['notify-error'] = 'fa-times';

    toast.info = function(message) {
        createNotification(message, 'notify-info');
    };

    toast.success = function(message) {
        createNotification(message, 'notify-success');
    };

    toast.warn = function(message) {
        createNotification(message, 'notify-warn');
    };

    toast.error = function(message) {
        createNotification(message, 'notify-error');
    };

    window.onMessage('toast.info', toast.info);
    window.onMessage('toast.success', toast.success);
    window.onMessage('toast.warn', toast.warn);
    window.onMessage('toast.error', toast.error);

    function createNotification(message, color) {
        var object = $('<div />', {
            class: color,
        });

        var icon = $('<i />', {
            class: 'fa ' + icons[color],
        });

        var message = $('<span />', {
            text: message,
        });

        icon.appendTo(object);
        message.appendTo(object);

        display(object);
        hideOverTime(object, 7000);
    }

    function display(object) {
        object.prependTo('#notifications');
        object.slideDown(200, object.fadeTo.bind(object, 200, 1));
    }

    function hideOverTime(object, time) {
        setTimeout(function() {
            object.fadeTo(300, 0, object.remove.bind(object));
        }, time);
    }
})();
